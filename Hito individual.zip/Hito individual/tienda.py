import re
import random

class Cliente:
    def __init__(self, nombre, email, contraseña, pais):
        self.nombre = nombre
        self.email = email
        self.contraseña = contraseña
        self.carrito = []
        self.pais = pais
    def registro_cliente(self):
        # Verificar si el cliente ya está registrado
        # Ingresar nueva información para el registro
        print("-----------------------------------------------------------------------------")
        nombre = input("Ingrese su nombre: ")
        while not nombre.strip():
            print("-----------------------------------------------------------------------------")
            print("El nombre no puede estar vacío.")
            nombre = input("Ingrese su nombre: ")

        print("-----------------------------------------------------------------------------")
        email = input("Ingrese su correo electrónico: ")
        while not email.strip() or not Cliente.validar_email(email):
            print("-----------------------------------------------------------------------------")
            if not email.strip():
                print("El correo electrónico no puede estar vacío.")
            else:
                print("El correo electrónico no es válido.")
            email = input("Ingrese su correo electrónico: ")

        print("-----------------------------------------------------------------------------")
        contraseña = input("Ingrese su contraseña: ")
        print("-----------------------------------------------------------------------------")
        while not contraseña.strip():
            print("La contraseña no puede estar vacía.")
            contraseña = input("Ingrese su contraseña: ")
        # Actualizar la información del cliente
        self.nombre = nombre
        self.email = email
        self.contraseña = contraseña

        print("Cliente registrado o iniciado sesión con éxito.")

    def validar_email(email):
        # Validar el formato del correo electrónico
        if re.match(r"[^@]+@[^@]+\.[^@]+", email):
            return True
        else:
            return False
    def agregar_producto(self, producto, cantidad, tienda):
        if producto in tienda.productos:
            stock_disponible = tienda.productos[producto]["stock"]

            # Verificar si hay suficiente stock
            if cantidad <= stock_disponible:
                # Agregar el producto y la cantidad al carrito
                self.carrito.append({"producto": producto, "cantidad": cantidad})

                # Actualizar el stock en el inventario
                tienda.productos[producto]["stock"] -= cantidad

                print(f"{cantidad} {producto}(s) agregado(s) al carrito.")
            else:
                print(f"No hay suficiente stock disponible para {producto}.")
        else:
            print(f"{producto} no está en el inventario.")

    def realizar_compra(self, tienda):

        if not self.carrito:
            print("El carrito está vacío. No hay productos para comprar.")
            return

        total = 0

        # Mostrar resumen del carrito
        print("Resumen del carrito:")
        for item in self.carrito:
            producto = item["producto"]
            cantidad = item["cantidad"]
            precio_unitario = tienda.productos[producto]["precio"]
            total_producto = precio_unitario * cantidad

            print(f"{producto}: Cantidad: {cantidad}, Precio unitario: ${precio_unitario}")

            total += total_producto

        # Mostrar el precio total
        print(f"\nPrecio total: ${total}")

        # Pedir confirmación para realizar la compra
        print("-----------------------------------------------------------------------------")
        confirmacion = input("¿Quieres proceder al pago? (si/no): ")

        if confirmacion.lower() == 'si':
            # Agregar lógica para solicitar información adicional (DNI, teléfono, dirección, etc.)
            print("-----------------------------------------------------------------------------")
            dni = input("Ingrese su DNI: ")
            if not dni.strip():
                print("-----------------------------------------------------------------------------")
                print("El DNI no puede estar vacío.")
                dni = input("Ingrese su DNI: ")
            print("-----------------------------------------------------------------------------")
            telefono = input("Ingrese su número de teléfono: ")
            if not telefono.strip():
                print("-----------------------------------------------------------------------------")
                print("El TLF no puede estar vacío.")
                dni = input("Ingrese su TLF: ")
            print("-----------------------------------------------------------------------------")
            print("-----------------------------------------------------------------------------")
            pais = input("Ingrese su país: ").lower()
            if not pais.strip():
                print("-----------------------------------------------------------------------------")
                print("El país no puede estar vacío.")
                pais = input("Ingrese su pais: ")
            while not pais in ["españa", "portugal", "italia", "francia", "china"]:
                print("-----------------------------------------------------------------------------")
                print("Lo siento, no exportamos a ese país.")
                pais = input("Ingrese su país o cancele la compra(x): ").lower()
                if pais.lower()=='x':
                    print('Adiós')
                    break
            self.pais=pais

            direccion = input("Ingrese su dirección de envío: ")
            if not direccion.strip():
                print("-----------------------------------------------------------------------------")
                print("La dirección no puede estar vacía.")
                direccion = input("Ingrese su dirección: ")
                print("-----------------------------------------------------------------------------")
                print("¡Compra realizada con éxito!")

                # Generar número de seguimiento y mostrarlo al cliente
                numero_seguimiento = self.generar_numero_seguimiento()
                print(f"Número de seguimiento: {numero_seguimiento}")
        else:
            print("Compra cancelada.")

    def generar_factura_pdf(self, tienda):

        tasas_iva = {"españa": 1.21, "francia": 1.20, "italia": 1.22, "china": 1.13, "portugal": 1.23}
        tasa_iva_cliente = tasas_iva.get(self.pais, 0.0)

        if not self.carrito:
            print("El carrito está vacío. No hay productos para generar factura.")
            return

        total = 0
        desea_factura = input("¿Desea factura? (si/no): ")
        if desea_factura.lower() == 'si':

            # Mostrar factura en consola
            print("Factura:")
            print("Producto        Cantidad        Precio unitario        Total")
            print("=" * 60)
            for item in self.carrito:
                producto = item["producto"]
                cantidad = item["cantidad"]
                precio_unitario = tienda.productos[producto]["precio"]
                total_producto = precio_unitario * cantidad * tasa_iva_cliente

                print(
                    f"{producto.ljust(15)}{str(cantidad).ljust(15)}${str(precio_unitario).ljust(22)}${total_producto}")

                total += total_producto

            print("=" * 60)
            print(f"Total: ${total}")
        if desea_factura.lower() == 'no':
            print('Tenga un buen día')

    def generar_numero_seguimiento(self):
        # Generar un número de seguimiento único
        return random.randint(1000, 9999)

class Tienda:
    def __init__(self):
        self.productos = {"iphone": {"precio": 10, "stock": 50},
                          "mac": {"precio": 20, "stock": 30},
                          "portatil": {"precio": 15, "stock": 40},
                          "espiradora": {"precio": 15, "stock": 40},
                          "plancha": {"precio": 15, "stock": 40}}

    def mostrar_inventario(self):
        # Mostrar el inventario de productos con precio y stock
        print("-----------------------------------------------------------------------------")
        print("Inventario de productos:\n")
        for producto, detalles in self.productos.items():
            print(f"{producto}: {detalles['precio']}€ / quedan {detalles['stock']}")



def main():
    # Iniciar sesión o registrar nuevo cliente
    cliente1=Cliente("","","","")
    cliente1.registro_cliente()

    # Inicializar tienda
    tienda = Tienda()

    # Mostrar inventario de productos
    tienda.mostrar_inventario()

    # Agregar productos al carrito
    while True:
        print("-----------------------------------------------------------------------------")
        producto = input("Ingrese el nombre del producto (o 'x' para dejar de agregar): ").lower()
        if not producto.strip():
            print("-----------------------------------------------------------------------------")
            print("La producto no puede estar vacía.")
            producto = input("Ingrese el nombre del producto (o 'x' para dejar de agregar): ")
        if producto=="x":
            break
        if producto in tienda.productos:
            cantidad = input("Ingrese la cantidad: ")
            while not cantidad.strip() or not cantidad.isdigit():
                print("-----------------------------------------------------------------------------")
                if not cantidad.strip():
                    print("La cantidad no puede estar vacía.")
                else:
                    print("Por favor, ingrese un número entero válido para la cantidad.")

                cantidad = input("Ingrese su cantidad: ")

            cantidad = int(cantidad)
            cliente1.agregar_producto(producto, cantidad, tienda)
        while producto not in tienda.productos:
            producto=input("El producto no está en el inventario. Por favor, ingrese un producto válido o salga(x): ")
            if producto == "x":
                break
            if producto in tienda.productos:
                cantidad = input("Ingrese la cantidad: ")
                while not cantidad.strip() or not cantidad.isdigit():
                    print("-----------------------------------------------------------------------------")
                    if not cantidad.strip():
                        print("La cantidad no puede estar vacía.")
                    else:
                        print("Por favor, ingrese un número entero válido para la cantidad.")

                    cantidad = input("Ingrese su cantidad: ")

                cantidad = int(cantidad)
                cliente1.agregar_producto(producto, cantidad, tienda)



    # Realizar compra
    while True:
        print("-----------------------------------------------------------------------------")
        respuesta = input("¿Desea realizar la compra? (si/no): ")
        if respuesta.lower() == 'si':
            cliente1.realizar_compra(tienda)
            cliente1.generar_factura_pdf(tienda)
            break
        elif respuesta.lower() == 'no':
            break
        else:
            print("Respuesta no válida. Intente nuevamente.")

if __name__ == "__main__":
    main()


