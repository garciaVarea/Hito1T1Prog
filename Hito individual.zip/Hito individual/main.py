import tienda as t

cliente=t.main()
